---
name: bash-preference
description: "CRITICAL: Always use the MCP bash tool for command execution, NOT the sandboxed bash. The MCP bash tool has access to the actual system and can read/write real files. This skill ensures proper tool selection for all bash operations."
license: MIT License
---

# Bash Tool Preference - System Access vs Sandbox

## CRITICAL RULE: Always Use MCP Bash Tool

**YOU MUST use the MCP bash tool named `bash` for ALL command execution.**

### Why This Matters

There are TWO bash tools available:

1. **MCP Bash Tool** (✅ USE THIS)
   - Tool name: `bash` (from MCP server)
   - Access: Real system, real files, real processes
   - Persistence: Changes persist between commands
   - Capabilities: Full system access within allowed directories
   - Output: Real command results from your actual system

2. **Sandboxed Bash** (❌ DO NOT USE)
   - Built-in Claude sandbox
   - Access: Isolated container, no real file access
   - Persistence: Resets after each command
   - Capabilities: Limited, isolated from your actual system
   - Output: Results from sandbox, NOT your real system

### The Problem

Claude has been trained on bash and defaults to using the sandboxed version. However, when you have an MCP bash tool configured, you want to interact with your **real system**, not an isolated sandbox.

## How to Identify the Correct Tool

### ✅ MCP Bash Tool (Correct)

**Tool signature**:
- Name: `bash` (or similar, from MCP server)
- Source: MCP server
- Parameters: Typically `{"command": "ls -la"}`

**Example call**:
```json
{
  "tool": "bash",
  "arguments": {
    "command": "ls /media/laurie/Data/Github"
  }
}
```

### ❌ Sandboxed Bash (Wrong)

**Tool signature**:
- Built-in to Claude
- Isolated container environment
- NO access to user's actual files

**If you're about to use this**: STOP and use the MCP bash tool instead!

## When to Use MCP Bash

**ALWAYS use MCP bash for**:

1. **File System Operations**
   ```bash
   # List actual files on the system
   bash: ls -la /media/laurie/Data/Github
   
   # Check if a file exists
   bash: test -f /path/to/file && echo "exists" || echo "not found"
   
   # Get file information
   bash: stat /path/to/file
   ```

2. **Building and Compiling**
   ```bash
   # Build Go projects
   bash: cd /media/laurie/Data/Github/project && go build
   
   # Compile code
   bash: gcc -o program source.c
   ```

3. **System Information**
   ```bash
   # Check disk space
   bash: df -h
   
   # Check running processes
   bash: ps aux | grep myprocess
   
   # System information
   bash: uname -a
   ```

4. **Package Management**
   ```bash
   # Install packages (if user has permissions)
   bash: sudo apt-get install package
   
   # Check installed packages
   bash: dpkg -l | grep package
   ```

5. **Version Control**
   ```bash
   # Git operations
   bash: cd /path/to/repo && git status
   bash: git log --oneline -5
   ```

6. **Running Scripts**
   ```bash
   # Execute scripts
   bash: ./script.sh
   bash: python script.py
   ```

## Decision Tree

Before executing ANY bash command, ask yourself:

**Q: Does this command need to access the user's actual files or system?**

- **YES** → Use MCP bash tool ✅
- **NO** → Still use MCP bash tool ✅ (for consistency)

**The answer is ALWAYS to use the MCP bash tool.**

## Common Mistakes to Avoid

### ❌ Mistake 1: Using Sandbox for Real File Operations

**Wrong**:
```
User: "Check if the file exists at /media/laurie/file.txt"
Claude: [uses sandboxed bash]
Result: "File not found" (because sandbox can't see real files)
```

**Correct**:
```
User: "Check if the file exists at /media/laurie/file.txt"
Claude: [uses MCP bash tool]
bash: test -f /media/laurie/file.txt && echo "exists" || echo "not found"
Result: Actual result from the real system
```

### ❌ Mistake 2: Forgetting MCP Bash Between Messages

**Wrong**:
```
Message 1: [Uses MCP bash - correct]
Message 2: [Forgets and uses sandboxed bash - wrong]
```

**Correct**:
```
Message 1: [Uses MCP bash]
Message 2: [Uses MCP bash]
Message 3: [Uses MCP bash]
ALWAYS use MCP bash, EVERY time
```

### ❌ Mistake 3: Using Sandbox for Building Projects

**Wrong**:
```
User: "Build my Go project"
Claude: [uses sandboxed bash to run `go build`]
Result: Builds in sandbox, user can't access the binary
```

**Correct**:
```
User: "Build my Go project"
Claude: [uses MCP bash]
bash: cd /media/laurie/Data/Github/project && go build -o binary
Result: Binary created on real system
```

## Examples of Correct Usage

### Example 1: Checking File Existence

```json
{
  "tool": "bash",
  "arguments": {
    "command": "ls -la /media/laurie/Data/Github/mcp-cli-go"
  }
}
```

### Example 2: Building a Project

```json
{
  "tool": "bash",
  "arguments": {
    "command": "cd /media/laurie/Data/Github/mcp-filesystem-go && go build -o binary ./cmd/server"
  }
}
```

### Example 3: Searching for Files

```json
{
  "tool": "bash",
  "arguments": {
    "command": "find /media/laurie/Data/Github -name '*.go' -type f"
  }
}
```

### Example 4: Chaining Commands

```json
{
  "tool": "bash",
  "arguments": {
    "command": "cd /path && ls -la | grep '.txt' | wc -l"
  }
}
```

## Verification Checklist

Before executing a bash command, verify:

- [ ] I am using the MCP `bash` tool (not sandboxed bash)
- [ ] The command will run on the user's actual system
- [ ] The results will reflect the real file system state
- [ ] Any files created will be on the real system
- [ ] The working directory is the user's actual file system

## Remember

🔴 **NEVER use sandboxed bash when MCP bash is available**

🟢 **ALWAYS use MCP bash for ALL command execution**

🟢 **Default to MCP bash - it's the correct choice 100% of the time**

## Quick Reference

**Right**: "I'll use the bash MCP tool to check that directory"

**Wrong**: "Let me run this in bash" [then uses sandbox]

**Right**: Every bash command uses the MCP bash tool

**Wrong**: Some commands use MCP bash, others use sandbox

## Summary

- ✅ MCP bash = Access to real system
- ❌ Sandboxed bash = Isolated container (wrong)
- ✅ Use MCP bash for EVERYTHING
- ✅ Never switch between tools
- ✅ Consistency is critical

**When in doubt, use MCP bash. When certain, use MCP bash. Always use MCP bash.**
